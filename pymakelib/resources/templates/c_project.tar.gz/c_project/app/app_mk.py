from pymakelib import module


@module.ModuleClass
class App(module.BasicCModule):
    pass