/*
 * main.c
 *
 *  Created on: Mar 18, 2021
 *      Author: <%= author =%>
 */
#include <stdio.h>


int main() {
	printf("Hello pymaketool!!\n");
	return 0;
}


